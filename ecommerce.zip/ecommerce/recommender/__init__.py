"""
Recommender package for recommendation engine services
"""
# Remove the import of engine functions