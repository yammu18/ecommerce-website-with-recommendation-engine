"""
Models package for recommendation algorithms
"""
# Remove all direct imports